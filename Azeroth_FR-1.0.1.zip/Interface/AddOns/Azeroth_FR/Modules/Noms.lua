-- ============================================================================
-- Azeroth_FR : noms affiches dans l'interface (version 0.4 ; depuis la 0.3 : minicarte rebranchee sur MinimapCluster).
-- - cadres d'unite : cible, focalisation, cible de la cible, boss (nom de la creature par le
--   numero tire de son GUID, verifie par l'empreinte du nom anglais) ;
-- - zones : minicarte (texte et infobulle), grand texte de zone a l'arrivee, carte du monde
--   (nom de la zone survolee, titre, listes deroulantes), en-tetes du journal (Quetes.lua),
--   noms de canaux « General - Zone » (Discussion.lua).
-- Affichage seulement : on passe APRES le jeu (hooksecurefunc, HookScript) et on ne change
-- que le texte d'une zone de texte. Les cadres d'unite sont securises : on ne touche ni a leurs
-- variables ni a leurs methodes, seulement au texte de leur zone « name » (permis par le jeu,
-- meme en combat).
-- LIMITE : les noms AU-DESSUS DES TETES (personnages, PNJ) sont dessines par le moteur du jeu,
-- hors de l'interface Lua : un add-on ne peut pas les changer. Ils restent en anglais.
-- ============================================================================
local A = AzerothFR
local P = A.Proteger

-- Petite memoire des noms de zone (la carte du monde redemande le meme nom a chaque image).
local memo, taille = {}, 0
local function NomZone(t)
    if type(t) ~= "string" or t == "" then return nil end
    local m = memo[t]
    if m ~= nil then return m or nil end
    local fr = A.Nom("zone", t) or false
    taille = taille + 1
    if taille > 500 then memo, taille = {}, 0 end
    memo[t] = fr
    return fr or nil
end
A.NomZone = NomZone

local function TraduireZoneTexte(zone, fn)
    if not zone or type(zone.GetText) ~= "function" then return end
    local t = zone:GetText()
    if not t or t == "" or A.DejaEcrit(zone, t) then return end
    local fr = (fn or NomZone)(t)
    if fr and fr ~= t then A.Ecrire(zone, fr) end
end
A.TraduireZoneTexte = TraduireZoneTexte

-- ----------------------------------------------------------------------------
-- Cadres d'unite (UnitFrame_Update est appele par la cible, la focalisation, la cible de la
-- cible et les cadres de boss ; UnitFrame_OnEvent pour UNIT_NAME_UPDATE).
-- ----------------------------------------------------------------------------
local function TraduireCadreUnite(cadre)
    if not A.Actif() or type(cadre) ~= "table" then return end
    local unite = cadre.overrideName or cadre.unit
    local zone = cadre.name
    if not unite or type(zone) ~= "table" or type(zone.GetText) ~= "function" then return end
    local t = zone:GetText()
    if not t or t == "" or A.DejaEcrit(zone, t) then return end
    local fr, en = A.NomUnite(unite)
    if fr and t == en then A.Ecrire(zone, fr) end
end
A.TraduireCadreUnite = TraduireCadreUnite

if type(UnitFrame_Update) == "function" then
    hooksecurefunc("UnitFrame_Update", P("UnitFrame_Update", TraduireCadreUnite))
end
if type(UnitFrame_OnEvent) == "function" then
    hooksecurefunc("UnitFrame_OnEvent", P("UnitFrame_OnEvent", function(cadre, evenement)
        if evenement == "UNIT_NAME_UPDATE" then TraduireCadreUnite(cadre) end
    end))
end

-- ----------------------------------------------------------------------------
-- Minicarte : nom de la zone et son infobulle.
-- Le client CoA (patch-B, Minimap.xml) relie l'evenement par <OnEvent function="Minimap_Update"/>
-- sur MinimapCluster : la fonction est CAPTUREE au chargement, un crochet pose sur le nom global
-- Minimap_Update ne s'execute jamais (essai 2 : « Northshire Valley »). Branchements retenus :
--   - MinimapCluster:HookScript("OnEvent") : passe apres le script du cadre, quel qu'il soit ;
--   - Minimap_SetTooltip, appele par son NOM GLOBAL a la fin de Minimap_Update et au survol ;
--   - notre propre cadre : PLAYER_ENTERING_WORLD et changements de zone, et une fois apres le
--     chargement de la famille « noms » (le texte a ete pose au chargement de l'interface, avant).
-- ----------------------------------------------------------------------------
local function TraduireBulleMinicarte()
    if not GameTooltip or not MinimapZoneTextButton or not GameTooltip:IsOwned(MinimapZoneTextButton) then return end
    local modifie = false
    for i = 1, GameTooltip:NumLines() do
        local l = _G["GameTooltipTextLeft" .. i]
        local t = l and l:GetText()
        local fr = t and NomZone(t)
        if fr and fr ~= t then l:SetText(fr); modifie = true end
    end
    if modifie then GameTooltip:Show() end
end

local function TraduireMinicarte()
    if not A.Actif() then return end
    TraduireZoneTexte(MinimapZoneText)
    TraduireBulleMinicarte()
end
A.TraduireMinicarte = TraduireMinicarte

if MinimapCluster and MinimapCluster.HookScript then
    MinimapCluster:HookScript("OnEvent", P("MinimapCluster.OnEvent", TraduireMinicarte))
end
if type(Minimap_SetTooltip) == "function" then
    hooksecurefunc("Minimap_SetTooltip", P("Minimap_SetTooltip", TraduireMinicarte))
end
local guetteurZone = CreateFrame("Frame")
for _, e in ipairs({ "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA" }) do guetteurZone:RegisterEvent(e) end
guetteurZone:SetScript("OnEvent", P("Noms.zone", TraduireMinicarte))
table.insert(A.AuDemarrage, TraduireMinicarte)
table.insert(A.AEntreeEnJeu, TraduireMinicarte)

-- ----------------------------------------------------------------------------
-- Grand texte de zone (a l'arrivee dans une zone ou une sous-zone).
-- ----------------------------------------------------------------------------
-- ZoneText_OnEvent (lie par function= sur ZoneTextFrame) pose ZoneTextString ET SubZoneTextString ;
-- SubZoneTextFrame n'a pas d'evenement : le crochet utile est celui de ZoneTextFrame.
local function TraduireTexteDeZone()
    if not A.Actif() then return end
    TraduireZoneTexte(ZoneTextString)
    TraduireZoneTexte(SubZoneTextString)
end
if ZoneTextFrame and ZoneTextFrame.HookScript then
    ZoneTextFrame:HookScript("OnEvent", P("ZoneText", TraduireTexteDeZone))
end
table.insert(A.AEntreeEnJeu, TraduireTexteDeZone)

-- ----------------------------------------------------------------------------
-- Carte du monde : nom de la zone survolee (pose a chaque image par WorldMapButton_OnUpdate),
-- titre de la fenetre, texte des listes deroulantes (continent, zone).
-- ----------------------------------------------------------------------------
-- (1.0.1) Le client CoA ajoute a la zone survolee ses niveaux, colores : « Western Plaguelands |cffff2020(51-60)|r ».
-- On traduit le nom et on garde la suite telle quelle.
local function NomZoneAvecNiveaux(t)
    local fr = NomZone(t)
    if fr then return fr end
    local nom, suite = string.match(t, "^(.-)(%s*|c%x%x%x%x%x%x%x%x%([^%)]*%)|r)$")
    if not nom then nom, suite = string.match(t, "^(.-)(%s+%([%d%s%-%+]+%))$") end
    if not nom or nom == "" then return nil end
    fr = NomZone(nom)
    return fr and (fr .. suite) or nil
end
A.NomZoneAvecNiveaux = NomZoneAvecNiveaux

local function TraduireCarte()
    if not A.Actif() then return end
    TraduireZoneTexte(WorldMapFrameAreaLabel, NomZoneAvecNiveaux)
    TraduireZoneTexte(WorldMapFrameTitle)
    TraduireZoneTexte(WorldMapZoneDropDownText)
    TraduireZoneTexte(WorldMapContinentDropDownText)
end
A.TraduireCarte = TraduireCarte
if WorldMapButton and WorldMapButton.HookScript then
    WorldMapButton:HookScript("OnUpdate", P("WorldMapButton.OnUpdate", function()
        if A.Actif() then TraduireZoneTexte(WorldMapFrameAreaLabel, NomZoneAvecNiveaux) end
    end, true))
end
for _, fn in ipairs({ "WorldMapFrame_SetMapName", "WorldMapZoneDropDown_Update", "WorldMapContinentsDropDown_Update" }) do
    if type(_G[fn]) == "function" then hooksecurefunc(fn, P(fn, TraduireCarte)) end
end
if WorldMapFrame and WorldMapFrame.HookScript then
    WorldMapFrame:HookScript("OnShow", P("WorldMapFrame.OnShow", TraduireCarte))
end

-- (1.0.1) Listes deroulantes « Continent » et « Zone » de la carte : les lignes de la liste ouverte.
-- On ne change que le texte des boutons (le choix se fait par leur numero) et, si le francais est plus long,
-- la largeur de la liste ; aucune variable du jeu n'est ecrite. Seules ces deux listes sont concernees.
local LISTES_CARTE = { WorldMapZoneDropDown = true, WorldMapContinentDropDown = true }
local function TraduireListeCarte()
    if not A.Actif() then return end
    local ouverte = UIDROPDOWNMENU_OPEN_MENU
    if type(ouverte) == "table" and type(ouverte.GetName) == "function" then ouverte = ouverte:GetName() end
    if not ouverte or not LISTES_CARTE[ouverte] then return end
    local liste = DropDownList1
    if not liste or type(liste.IsShown) ~= "function" or not liste:IsShown() then return end
    local large, boutons = 0, {}
    for i = 1, (UIDROPDOWNMENU_MAXBUTTONS or 32) do
        local b = _G["DropDownList1Button" .. i]
        if not b then break end
        if type(b.IsShown) ~= "function" or b:IsShown() then
            TraduireZoneTexte(b)
            boutons[#boutons + 1] = b
            if type(b.GetTextWidth) == "function" then
                local w = (b:GetTextWidth() or 0) + 40
                if w > large then large = w end
            end
        end
    end
    if large > 0 and type(liste.GetWidth) == "function" and large + 25 > (liste:GetWidth() or 0) then
        for _, b in ipairs(boutons) do if type(b.SetWidth) == "function" then b:SetWidth(large) end end
        liste:SetWidth(large + 25)
    end
end
A.TraduireListeCarte = TraduireListeCarte
if type(ToggleDropDownMenu) == "function" then
    hooksecurefunc("ToggleDropDownMenu", P("ToggleDropDownMenu.carte", TraduireListeCarte))
end
